# GDM — Geometry Dash mod manager & maker (Android)

GDM is an Android app with two jobs:

1. **Mod manager:** keeps your `.geode` mods in one place, lets you switch them on or off, and copies the enabled ones into the game's Geode mods folder.
2. **Mod maker:** a form that generates a complete Geode mod project (`mod.json`, CMake file, C++ starter code, and a GitHub workflow that builds it) and saves it as a `.zip`.

**What GDM is not:** it does not inject code into Geometry Dash. Mods are loaded by [Geode](https://docs.geode-sdk.org/), so you still need Geode's Android launcher. GDM is the manager and project maker around it.

## Get the APK

There is no prebuilt APK in this download, because the environment this project was written in could not reach Google's Android build servers. Pick one of these:

### Option A: build it with GitHub (no computer needed)

1. Create a free GitHub account and a new repository.
2. Upload every file and folder of this project (keep `.github/workflows/build-apk.yml` and the `gradle/` folder).
3. Open the repository's **Actions** tab, choose **Build GDM APK**, and press **Run workflow** (pushing to `main` also starts it).
4. When the run is green, open it and download the **GDM-debug-apk** artifact, unzip it, and install the `.apk`. Android will ask you to allow installing from your browser or file manager.

### Option B: build it with Android Studio

Open this folder in Android Studio and press Run, or run `./gradlew assembleDebug`. The APK ends up in `app/build/outputs/apk/debug/`.

## Using GDM

1. Install Geode's Android launcher and start the game once.
2. **Mods tab → Choose folder** and pick the game's mods folder. Geode's docs list it as `Android/media/com.geode.launcher/game/geode/mods`; the picker opens there when it can.
3. **Import** `.geode` files, switch mods on or off, then tap **Sync to game**. Disabled mods are removed from the game folder on sync; files GDM doesn't know about are never touched.
4. **Maker tab:** fill in the form, tap **Generate**, save the zip, then follow the `README.md` inside it to build your mod on GitHub.

## What was tested

- The generator, `.geode` reader, JSON reader and mod library are plain Java and are covered by `tools/CoreSelfTest.java` (97 checks, all passing). The GitHub workflow runs them before building the APK. Run them yourself with:
  `javac -d out app/src/main/java/dev/gdm/core/*.java tools/CoreSelfTest.java && java -cp out CoreSelfTest`

## What was NOT tested

- **The Android app itself has never been compiled or run.** The sandbox it was written in has no Android SDK. If the first build reports an error, it's most likely a small typo in `MainActivity`, `Ui` or `GameSync`; the error message will point at the line.
- **Folder access and syncing** use Android's folder picker. Whether your phone's picker lets you select the Geode folder depends on your Android version and the launcher's setup.
- **The generated mod projects** follow Geode's standard template and build workflow as far as its public docs describe them, but they were not built against the real Geode SDK. The defaults for the Geode version (`v5.11.2`) and Geometry Dash version (`2.2081`) came from third-party pages, so double-check them in the Maker tab. If a build complains, running `geode new` on a computer gives the official up-to-date template.

## Project layout

```
app/src/main/java/dev/gdm/core/   pure-Java logic (tested): ModSpec, ProjectGenerator, GeodeModInfo, ModLibrary, MiniJson
app/src/main/java/dev/gdm/app/    Android UI: MainActivity, Ui, GameSync
tools/CoreSelfTest.java           self-test for the core package
.github/workflows/build-apk.yml   builds the APK on GitHub
```

The app has no third-party dependencies and uses only the Android framework (minSdk 26, targetSdk 35, Android Gradle Plugin 8.7.3, Gradle 8.9).
