import dev.gdm.core.GeodeModInfo;
import dev.gdm.core.MiniJson;
import dev.gdm.core.ModLibrary;
import dev.gdm.core.ModSpec;
import dev.gdm.core.ProjectGenerator;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 * Plain-Java checks for the logic that does not need Android.
 * Run:  javac -d out app/src/main/java/dev/gdm/core/*.java tools/CoreSelfTest.java && java -cp out CoreSelfTest
 */
public class CoreSelfTest {
    private static int checks = 0;

    private static void check(boolean ok, String what) {
        checks++;
        if (!ok) {
            System.out.println("FAIL: " + what);
            System.exit(1);
        }
    }

    public static void main(String[] args) throws Exception {
        testMiniJson();
        testSpec();
        testGenerator();
        testZip();
        testModInfo();
        testLibrary();
        System.out.println("ALL TESTS PASSED (" + checks + " checks)");
    }

    // ---------------------------------------------------------------------------------------------

    private static void testMiniJson() {
        Object o = MiniJson.parse("{ // comment\n \"a\": [1, 2.5, true, null, \"x\\u0041\\n\",], /* c */ \"b\": {\"c\": false,}, }");
        Map<?, ?> m = (Map<?, ?>) o;
        List<?> a = (List<?>) m.get("a");
        check(a.size() == 5, "array size with trailing comma");
        check(((Double) a.get(1)) == 2.5, "number");
        check(Boolean.TRUE.equals(a.get(2)), "true");
        check(a.get(3) == null, "null");
        check("xA\n".equals(a.get(4)), "string escapes");
        check(Boolean.FALSE.equals(((Map<?, ?>) m.get("b")).get("c")), "nested object");
        check(MiniJson.parse("﻿{\"k\":1}") instanceof Map, "BOM tolerated");
        for (String bad : new String[]{"", "{", "{\"a\" 1}", "[1 2]", "{\"a\":}", "nope", "{\"a\":1} x", "\"abc"}) {
            boolean threw = false;
            try {
                MiniJson.parse(bad);
            } catch (IllegalArgumentException e) {
                threw = true;
            }
            check(threw, "rejects bad json: " + bad);
        }
    }

    private static ModSpec goodSpec() {
        ModSpec s = new ModSpec();
        s.name = "Cool Mod";
        s.developer = "Spartan";
        s.id = "spartan.cool-mod";
        s.description = "Does cool things.";
        return s;
    }

    private static void testSpec() {
        ModSpec s = goodSpec();
        s.normalize();
        check(s.validate().isEmpty(), "good spec validates");
        check("v1.0.0".equals(s.version), "default version");

        ModSpec t = goodSpec();
        t.version = "2.1.0"; // missing v gets added
        t.geodeVersion = "5.0.0";
        t.id = "  Spartan.Cool-Mod ";
        t.normalize();
        check("v2.1.0".equals(t.version) && "v5.0.0".equals(t.geodeVersion), "v prefix added");
        check("spartan.cool-mod".equals(t.id), "id lower-cased and trimmed");
        check("2.1.0".equals(t.versionNumbers()), "version numbers");

        ModSpec u = goodSpec();
        u.version = "v1.0.0-beta.1";
        u.normalize();
        check(u.validate().isEmpty() && "1.0.0".equals(u.versionNumbers()), "prerelease version");

        String[][] bad = {
                {"id", "Has Space"}, {"id", "a"}, {"id", ""}, {"version", "banana"}, {"geode", "v5"},
                {"gd", "twenty"}, {"name", ""}, {"developer", ""}
        };
        for (String[] b : bad) {
            ModSpec x = goodSpec();
            switch (b[0]) {
                case "id": x.id = b[1]; break;
                case "version": x.version = b[1]; break;
                case "geode": x.geodeVersion = b[1]; break;
                case "gd": x.gdVersion = b[1]; break;
                case "name": x.name = b[1]; break;
                default: x.developer = b[1]; break;
            }
            x.normalize();
            check(!x.validate().isEmpty(), "rejects " + b[0] + "=" + b[1]);
        }

        check("spartan.cool-mod".equals(ModSpec.suggestId("Spartan", "Cool Mod!")), "suggestId");
        check("cool-mod".equals(ModSpec.suggestId("", "Cool Mod")), "suggestId without developer");
        check("".equals(ModSpec.suggestId("", "")), "suggestId empty");
        check("CoolMod".equals(goodSpec().cmakeName()), "cmake name");
        ModSpec digits = goodSpec();
        digits.name = "9 Lives";
        check("Mod9Lives".equals(digits.cmakeName()), "cmake name starting with digit");
        ModSpec weird = goodSpec();
        weird.name = "モッド";
        check("MyMod".equals(weird.cmakeName()) && "my-mod".equals(weird.fileBase()), "non-ascii name falls back");
    }

    private static void testGenerator() {
        ModSpec s = goodSpec();
        Map<String, String> f = ProjectGenerator.generate(s);
        String[] expected = {"mod.json", "CMakeLists.txt", "src/main.cpp", "about.md", "changelog.md", "README.md",
                ".gitignore", ".github/workflows/build.yml"};
        for (String e : expected) check(f.containsKey(e), "generated " + e);

        Map<?, ?> mod = (Map<?, ?>) MiniJson.parse(f.get("mod.json"));
        check("spartan.cool-mod".equals(mod.get("id")), "mod.json id");
        check("Cool Mod".equals(mod.get("name")), "mod.json name");
        check("v1.0.0".equals(mod.get("version")), "mod.json version");
        check("Spartan".equals(mod.get("developer")), "mod.json developer");
        check("v5.11.2".equals(mod.get("geode")), "mod.json geode");
        check("2.2081".equals(((Map<?, ?>) mod.get("gd")).get("android")), "mod.json gd.android");

        check(f.get("CMakeLists.txt").contains("project(CoolMod VERSION 1.0.0)"), "cmake project line");
        check(!f.get("CMakeLists.txt").contains("@@"), "no unreplaced placeholders in CMake");
        check(f.get("src/main.cpp").contains("Hello from Cool Mod!"), "main.cpp mentions mod name");
        check(f.get("src/main.cpp").contains("class $modify(MyMenuLayer, MenuLayer)"), "main.cpp hooks MenuLayer");
        check(f.get(".github/workflows/build.yml").contains("geode-sdk/build-geode-mod@main"), "workflow uses build action");
        check(f.get(".github/workflows/build.yml").contains("${{ matrix.config.target }}"), "workflow keeps ${{ }}");
        for (Map.Entry<String, String> e : f.entrySet()) {
            check(!e.getValue().contains("@@"), "no unreplaced placeholders in " + e.getKey());
        }

        // nasty characters must not break JSON or C++
        ModSpec n = goodSpec();
        n.name = "Say \"Hi\" \\ now?";
        n.description = "Line one\nline \"two\"";
        Map<String, String> g = ProjectGenerator.generate(n);
        Map<?, ?> nm = (Map<?, ?>) MiniJson.parse(g.get("mod.json"));
        check("Say \"Hi\" \\ now?".equals(nm.get("name")), "JSON round-trips nasty name");
        check("Line one line \"two\"".equals(nm.get("description")), "description flattened to one line");
        check(g.get("src/main.cpp").contains("Hello from Say \\\"Hi\\\" \\\\ now\\?!"), "C++ literal escaped");

        ModSpec empty = goodSpec();
        empty.template = ModSpec.Template.EMPTY;
        String main = ProjectGenerator.generate(empty).get("src/main.cpp");
        check(main.contains("$on_mod(Loaded)") && !main.contains("MenuLayer"), "empty template");

        ModSpec noDesc = goodSpec();
        noDesc.description = "";
        Map<?, ?> nd = (Map<?, ?>) MiniJson.parse(ProjectGenerator.generate(noDesc).get("mod.json"));
        check(((String) nd.get("description")).length() > 0, "default description filled in");

        boolean threw = false;
        try {
            ModSpec bad = goodSpec();
            bad.id = "NOT VALID";
            bad.id = "!";
            ProjectGenerator.generate(bad);
        } catch (IllegalArgumentException e) {
            threw = true;
        }
        check(threw, "generate() rejects invalid spec");
    }

    private static void testZip() throws IOException {
        Map<String, String> f = ProjectGenerator.generate(goodSpec());
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ProjectGenerator.writeZip(f, out, "cool-mod");
        Map<String, String> back = new LinkedHashMap<>();
        try (ZipInputStream zin = new ZipInputStream(new ByteArrayInputStream(out.toByteArray()), StandardCharsets.UTF_8)) {
            ZipEntry e;
            while ((e = zin.getNextEntry()) != null) {
                ByteArrayOutputStream b = new ByteArrayOutputStream();
                ModLibrary.copy(zin, b);
                back.put(e.getName(), new String(b.toByteArray(), StandardCharsets.UTF_8));
            }
        }
        check(back.size() == f.size(), "zip has every file");
        for (Map.Entry<String, String> e : f.entrySet()) {
            check(e.getValue().equals(back.get("cool-mod/" + e.getKey())), "zip content matches for " + e.getKey());
        }
    }

    // ---- .geode helpers ----------------------------------------------------------------------

    private static byte[] geodeBytes(String modJson) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (ZipOutputStream z = new ZipOutputStream(out)) {
            if (modJson != null) {
                z.putNextEntry(new ZipEntry("mod.json"));
                z.write(modJson.getBytes(StandardCharsets.UTF_8));
                z.closeEntry();
            }
            z.putNextEntry(new ZipEntry("thing.android64.so"));
            z.write(new byte[]{1, 2, 3});
            z.closeEntry();
        }
        return out.toByteArray();
    }

    private static File tempFile(byte[] data) throws IOException {
        File f = File.createTempFile("gdm-test-", ".geode");
        f.deleteOnExit();
        try (FileOutputStream o = new FileOutputStream(f)) {
            o.write(data);
        }
        return f;
    }

    private static void testModInfo() throws IOException {
        File ok = tempFile(geodeBytes("// hand written\n{\"id\":\"dev.mod\",\"name\":\"My Mod\",\"version\":\"v1.2.3\","
                + "\"developers\":[\"Alice\",\"Bob\"],\"description\":\"Hi\",}"));
        GeodeModInfo info = GeodeModInfo.read(ok);
        check("dev.mod".equals(info.id) && "My Mod".equals(info.name) && "v1.2.3".equals(info.version), "reads id/name/version");
        check("Alice".equals(info.developer) && "Hi".equals(info.description), "reads developers[0] and description");

        GeodeModInfo noName = GeodeModInfo.read(tempFile(geodeBytes("{\"id\":\"only.id\"}")));
        check("only.id".equals(noName.name), "name falls back to id");

        expectIo(tempFile("not a zip at all".getBytes(StandardCharsets.UTF_8)), "non-zip rejected");
        expectIo(tempFile(geodeBytes(null)), "zip without mod.json rejected");
        expectIo(tempFile(geodeBytes("{broken")), "bad json rejected");
        expectIo(tempFile(geodeBytes("{\"name\":\"x\"}")), "mod.json without id rejected");
    }

    private static void expectIo(File f, String what) {
        boolean threw = false;
        try {
            GeodeModInfo.read(f);
        } catch (IOException e) {
            threw = e.getMessage() != null && !e.getMessage().isEmpty();
        }
        check(threw, what);
    }

    private static void testLibrary() throws IOException {
        File dir = Files.createTempDirectory("gdm-lib-").toFile();
        ModLibrary lib = new ModLibrary(new File(dir, "mods"));
        check(lib.list().isEmpty(), "library starts empty");

        byte[] a = geodeBytes("{\"id\":\"alpha.mod\",\"name\":\"Alpha\",\"version\":\"v1.0.0\",\"developer\":\"A\"}");
        byte[] b = geodeBytes("{\"id\":\"beta.mod\",\"name\":\"beta\",\"version\":\"v2.0.0\",\"developer\":\"B\"}");
        ModLibrary.Entry ea = lib.importMod(new ByteArrayInputStream(a));
        lib.importMod(new ByteArrayInputStream(b));
        check(ea.enabled && "alpha.mod".equals(ea.id), "import returns enabled entry");

        List<ModLibrary.Entry> list = lib.list();
        check(list.size() == 2, "two mods listed");
        check("Alpha".equals(list.get(0).displayName()) && "beta".equals(list.get(1).displayName()), "sorted by name, case-insensitive");

        lib.setEnabled("alpha.mod", false);
        list = lib.list();
        check(!list.get(0).enabled && list.get(1).enabled, "disable keeps other mod enabled");
        check(list.get(0).file.getName().equals("alpha.mod.geode.disabled"), "disabled file name");

        // re-importing a disabled mod keeps it disabled and does not duplicate it
        ModLibrary.Entry again = lib.importMod(new ByteArrayInputStream(a));
        check(!again.enabled, "re-import keeps disabled state");
        check(lib.list().size() == 2, "re-import does not duplicate");

        lib.setEnabled("alpha.mod", true);
        check(lib.list().get(0).enabled, "re-enable");
        lib.setEnabled("alpha.mod", true); // no-op

        lib.remove("alpha.mod");
        check(lib.list().size() == 1, "remove deletes the mod");

        // bad imports leave nothing behind
        int before = new File(dir, "mods").list().length;
        try {
            lib.importMod(new ByteArrayInputStream("garbage".getBytes(StandardCharsets.UTF_8)));
            check(false, "garbage import should throw");
        } catch (IOException expected) {
            // good
        }
        try {
            lib.importMod(new ByteArrayInputStream(geodeBytes("{\"id\":\"../evil\",\"name\":\"x\"}")));
            check(false, "path-traversal id should throw");
        } catch (IOException expected) {
            // good
        }
        check(new File(dir, "mods").list().length == before, "failed imports leave no temp files");
        check(!new File(dir, "evil.geode").exists(), "nothing written outside the library");

        try {
            lib.setEnabled("../x", true);
            check(false, "unsafe id in setEnabled should throw");
        } catch (IOException expected) {
            // good
        }
    }
}
