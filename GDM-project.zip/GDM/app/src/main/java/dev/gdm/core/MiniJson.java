package dev.gdm.core;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Tiny dependency-free JSON reader. Tolerates comments and trailing commas,
 * because hand-written mod.json files often contain them.
 *
 * Objects become LinkedHashMap, arrays ArrayList, numbers Double,
 * strings String, booleans Boolean, null stays null.
 */
public final class MiniJson {
    private final String s;
    private int i;

    private MiniJson(String s) {
        this.s = s;
    }

    public static Object parse(String text) {
        if (text == null) throw new IllegalArgumentException("No JSON text");
        if (text.startsWith("﻿")) text = text.substring(1);
        MiniJson p = new MiniJson(text);
        p.skip();
        Object v = p.value();
        p.skip();
        if (p.i != p.s.length()) throw p.error("Unexpected data after JSON value");
        return v;
    }

    private IllegalArgumentException error(String msg) {
        return new IllegalArgumentException(msg + " at position " + i);
    }

    private void skip() {
        while (i < s.length()) {
            char c = s.charAt(i);
            if (c == ' ' || c == '\t' || c == '\n' || c == '\r') {
                i++;
            } else if (c == '/' && i + 1 < s.length() && s.charAt(i + 1) == '/') {
                while (i < s.length() && s.charAt(i) != '\n') i++;
            } else if (c == '/' && i + 1 < s.length() && s.charAt(i + 1) == '*') {
                int end = s.indexOf("*/", i + 2);
                if (end < 0) throw error("Unterminated comment");
                i = end + 2;
            } else {
                break;
            }
        }
    }

    private Object value() {
        if (i >= s.length()) throw error("Unexpected end of JSON");
        char c = s.charAt(i);
        switch (c) {
            case '{':
                return object();
            case '[':
                return array();
            case '"':
                return string();
            case 't':
                literal("true");
                return Boolean.TRUE;
            case 'f':
                literal("false");
                return Boolean.FALSE;
            case 'n':
                literal("null");
                return null;
            default:
                if (c == '-' || (c >= '0' && c <= '9')) return number();
                throw error("Unexpected character '" + c + "'");
        }
    }

    private void literal(String word) {
        if (!s.startsWith(word, i)) throw error("Expected " + word);
        i += word.length();
    }

    private Map<String, Object> object() {
        Map<String, Object> m = new LinkedHashMap<>();
        i++; // {
        skip();
        while (true) {
            if (i >= s.length()) throw error("Unterminated object");
            if (s.charAt(i) == '}') {
                i++;
                return m;
            }
            if (s.charAt(i) != '"') throw error("Expected a string key");
            String key = string();
            skip();
            if (i >= s.length() || s.charAt(i) != ':') throw error("Expected ':'");
            i++;
            skip();
            m.put(key, value());
            skip();
            if (i < s.length() && s.charAt(i) == ',') {
                i++;
                skip();
            } else if (i < s.length() && s.charAt(i) == '}') {
                // closed on the next loop pass
            } else {
                throw error("Expected ',' or '}'");
            }
        }
    }

    private List<Object> array() {
        List<Object> a = new ArrayList<>();
        i++; // [
        skip();
        while (true) {
            if (i >= s.length()) throw error("Unterminated array");
            if (s.charAt(i) == ']') {
                i++;
                return a;
            }
            a.add(value());
            skip();
            if (i < s.length() && s.charAt(i) == ',') {
                i++;
                skip();
            } else if (i < s.length() && s.charAt(i) == ']') {
                // closed on the next loop pass
            } else {
                throw error("Expected ',' or ']'");
            }
        }
    }

    private String string() {
        StringBuilder sb = new StringBuilder();
        i++; // opening quote
        while (true) {
            if (i >= s.length()) throw error("Unterminated string");
            char c = s.charAt(i++);
            if (c == '"') return sb.toString();
            if (c != '\\') {
                sb.append(c);
                continue;
            }
            if (i >= s.length()) throw error("Bad escape");
            char e = s.charAt(i++);
            switch (e) {
                case '"':
                    sb.append('"');
                    break;
                case '\\':
                    sb.append('\\');
                    break;
                case '/':
                    sb.append('/');
                    break;
                case 'b':
                    sb.append('\b');
                    break;
                case 'f':
                    sb.append('\f');
                    break;
                case 'n':
                    sb.append('\n');
                    break;
                case 'r':
                    sb.append('\r');
                    break;
                case 't':
                    sb.append('\t');
                    break;
                case 'u':
                    if (i + 4 > s.length()) throw error("Bad unicode escape");
                    try {
                        sb.append((char) Integer.parseInt(s.substring(i, i + 4), 16));
                    } catch (NumberFormatException ex) {
                        throw error("Bad unicode escape");
                    }
                    i += 4;
                    break;
                default:
                    throw error("Bad escape \\" + e);
            }
        }
    }

    private Double number() {
        int start = i;
        while (i < s.length() && "+-0123456789.eE".indexOf(s.charAt(i)) >= 0) i++;
        try {
            return Double.valueOf(s.substring(start, i));
        } catch (NumberFormatException ex) {
            throw error("Bad number");
        }
    }
}
