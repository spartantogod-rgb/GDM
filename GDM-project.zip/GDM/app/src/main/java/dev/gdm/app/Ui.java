package dev.gdm.app;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Small helpers so MainActivity can build its screens in code without any XML layouts. */
final class Ui {
    static final int BG = 0xFF0F1115;
    static final int CARD = 0xFF1A1D24;
    static final int FIELD = 0xFF262B36;
    static final int ACCENT = 0xFF38BDF8;
    static final int TEXT = 0xFFE5E7EB;
    static final int MUTED = 0xFF9CA3AF;
    static final int DANGER = 0xFFF87171;
    static final int ON_ACCENT = 0xFF06121A;

    private final Context ctx;
    private final float density;

    Ui(Context ctx) {
        this.ctx = ctx;
        this.density = ctx.getResources().getDisplayMetrics().density;
    }

    int dp(int v) {
        return Math.round(v * density);
    }

    GradientDrawable round(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(ctx);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    Button button(String label, boolean primary, View.OnClickListener onClick) {
        Button b = new Button(ctx);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTextColor(primary ? ON_ACCENT : TEXT);
        b.setStateListAnimator(null);
        b.setPadding(dp(14), dp(10), dp(14), dp(10));
        b.setBackground(new RippleDrawable(
                ColorStateList.valueOf(0x33FFFFFF),
                round(primary ? ACCENT : FIELD, 12),
                round(0xFFFFFFFF, 12)));
        b.setOnClickListener(onClick);
        return b;
    }

    EditText field(String hint, String initial) {
        EditText e = new EditText(ctx);
        e.setHint(hint);
        e.setHintTextColor(MUTED);
        e.setTextColor(TEXT);
        e.setTextSize(15);
        e.setSingleLine(true);
        if (initial != null) e.setText(initial);
        e.setBackground(round(FIELD, 10));
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        return e;
    }

    /** A rounded panel; vertical by default. */
    LinearLayout card() {
        LinearLayout c = new LinearLayout(ctx);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(round(CARD, 14));
        c.setPadding(dp(14), dp(14), dp(14), dp(14));
        return c;
    }

    /** Adds a child to a vertical layout, full width, with a top margin. */
    void add(LinearLayout parent, View child, int topMarginDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(topMarginDp);
        parent.addView(child, lp);
    }

    /** Layout params for a child of a horizontal row that shares the width equally. */
    LinearLayout.LayoutParams weighted(int leftMarginDp, int rightMarginDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.leftMargin = dp(leftMarginDp);
        lp.rightMargin = dp(rightMarginDp);
        return lp;
    }
}
