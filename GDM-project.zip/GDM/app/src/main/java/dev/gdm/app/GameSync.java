package dev.gdm.app;

import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import dev.gdm.core.ModLibrary;

/**
 * Copies the mods in GDM's library into the game's mods folder, which the user picked with the
 * system folder picker (so no special storage permission is needed).
 * Enabled mods are written as "<id>.geode"; disabled mods are removed from the game folder.
 * Files in the game folder that GDM does not know about are never touched.
 */
final class GameSync {
    private GameSync() {
    }

    static final class Result {
        int copied;
        int removed;
        final List<String> problems = new ArrayList<>();
    }

    static Result sync(ContentResolver cr, Uri treeUri, List<ModLibrary.Entry> mods) {
        Result result = new Result();
        String rootId = DocumentsContract.getTreeDocumentId(treeUri);
        Uri rootDoc = DocumentsContract.buildDocumentUriUsingTree(treeUri, rootId);

        Map<String, String> existing;
        try {
            existing = listChildren(cr, treeUri, rootId);
        } catch (Exception ex) {
            result.problems.add("Can't read the game folder (" + ex.getMessage() + "). Choose the folder again.");
            return result;
        }

        for (ModLibrary.Entry mod : mods) {
            String gameName = mod.id + ".geode";
            String existingId = existing.get(gameName);
            try {
                if (mod.enabled) {
                    if (existingId != null) {
                        DocumentsContract.deleteDocument(cr, DocumentsContract.buildDocumentUriUsingTree(treeUri, existingId));
                    }
                    Uri created = DocumentsContract.createDocument(cr, rootDoc, "application/octet-stream", gameName);
                    if (created == null) throw new IOException("could not create " + gameName);
                    try (InputStream in = new FileInputStream(mod.file);
                         OutputStream out = cr.openOutputStream(created, "w")) {
                        if (out == null) throw new IOException("could not write " + gameName);
                        ModLibrary.copy(in, out);
                    }
                    result.copied++;
                } else if (existingId != null) {
                    DocumentsContract.deleteDocument(cr, DocumentsContract.buildDocumentUriUsingTree(treeUri, existingId));
                    result.removed++;
                }
            } catch (Exception ex) {
                result.problems.add(mod.displayName() + ": " + ex.getMessage());
            }
        }
        return result;
    }

    /** display name -> document id for the direct children of a folder. */
    private static Map<String, String> listChildren(ContentResolver cr, Uri treeUri, String parentDocId) {
        Map<String, String> map = new HashMap<>();
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentDocId);
        String[] columns = {
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME
        };
        try (Cursor c = cr.query(children, columns, null, null, null)) {
            if (c != null) {
                while (c.moveToNext()) {
                    map.put(c.getString(1), c.getString(0));
                }
            }
        }
        return map;
    }
}
