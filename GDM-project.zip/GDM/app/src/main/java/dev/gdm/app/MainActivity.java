package dev.gdm.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import dev.gdm.core.ModLibrary;
import dev.gdm.core.ModSpec;
import dev.gdm.core.ProjectGenerator;

/** GDM: manage Geometry Dash (Geode) mods, and generate new mod projects. The whole UI is built in code. */
@SuppressWarnings("deprecation")
public class MainActivity extends Activity {
    private static final int REQ_IMPORT = 1;
    private static final int REQ_TREE = 2;
    private static final int REQ_SAVE_ZIP = 3;

    private static final String KEY_TREE = "game_tree_uri";
    /** Where Geode's Android launcher keeps mods, per the Geode docs. Only used as the picker's starting point. */
    private static final String GEODE_MODS_DOC_ID = "primary:Android/media/com.geode.launcher/game/geode/mods";

    private Ui ui;
    private SharedPreferences prefs;
    private ModLibrary library;

    private final List<View> panels = new ArrayList<>();
    private final List<TextView> tabs = new ArrayList<>();

    private LinearLayout modsList;
    private TextView gameFolderText;

    private EditText nameField;
    private EditText devField;
    private EditText idField;
    private EditText descField;
    private EditText versionField;
    private EditText geodeField;
    private EditText gdField;
    private Spinner templateSpinner;
    private TextView makerError;
    private TextView makerPreview;
    private boolean idEdited = false;
    private boolean autoFilling = false;
    private ModSpec pendingSpec;

    // ---------------------------------------------------------------------------------------------
    // Setup
    // ---------------------------------------------------------------------------------------------

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ui = new Ui(this);
        prefs = getSharedPreferences("gdm", MODE_PRIVATE);
        library = new ModLibrary(new File(getFilesDir(), "mods"));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        root.setOnApplyWindowInsetsListener(MainActivity::applyInsets);
        setContentView(root);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(ui.dp(16), ui.dp(12), ui.dp(16), ui.dp(4));
        header.addView(ui.text("GDM", 28, Ui.ACCENT, true));
        header.addView(ui.text("Geometry Dash mod manager & maker", 13, Ui.MUTED, false));
        root.addView(header, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout tabBar = new LinearLayout(this);
        tabBar.setOrientation(LinearLayout.HORIZONTAL);
        tabBar.setPadding(ui.dp(12), ui.dp(8), ui.dp(12), ui.dp(4));
        root.addView(tabBar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        String[] tabNames = {"Mods", "Maker", "Setup"};
        for (int i = 0; i < tabNames.length; i++) {
            final int index = i;
            TextView tab = ui.text(tabNames[i], 15, Ui.MUTED, true);
            tab.setGravity(Gravity.CENTER);
            tab.setPadding(0, ui.dp(10), 0, ui.dp(10));
            tab.setOnClickListener(v -> showTab(index));
            tabBar.addView(tab, ui.weighted(4, 4));
            tabs.add(tab);
        }

        FrameLayout host = new FrameLayout(this);
        root.addView(host, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        buildModsPanel(newPanel(host));
        buildMakerPanel(newPanel(host));
        buildSetupPanel(newPanel(host));

        showTab(0);
        refreshGameFolder();
        refreshMods();
    }

    /** Keeps content out from under the status bar, navigation bar and (on Android 15+) the keyboard. */
    private static WindowInsets applyInsets(View v, WindowInsets insets) {
        int left;
        int top;
        int right;
        int bottom;
        if (Build.VERSION.SDK_INT >= 30) {
            int types = WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout();
            if (Build.VERSION.SDK_INT >= 35) types |= WindowInsets.Type.ime();
            android.graphics.Insets bars = insets.getInsets(types);
            left = bars.left;
            top = bars.top;
            right = bars.right;
            bottom = bars.bottom;
        } else {
            left = insets.getSystemWindowInsetLeft();
            top = insets.getSystemWindowInsetTop();
            right = insets.getSystemWindowInsetRight();
            bottom = insets.getSystemWindowInsetBottom();
        }
        v.setPadding(left, top, right, bottom);
        return insets;
    }

    private LinearLayout newPanel(FrameLayout host) {
        ScrollView scroll = new ScrollView(this);
        LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        column.setPadding(ui.dp(16), ui.dp(8), ui.dp(16), ui.dp(32));
        scroll.addView(column);
        host.addView(scroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        panels.add(scroll);
        return column;
    }

    private void showTab(int index) {
        for (int i = 0; i < panels.size(); i++) {
            boolean selected = i == index;
            panels.get(i).setVisibility(selected ? View.VISIBLE : View.GONE);
            TextView tab = tabs.get(i);
            tab.setTextColor(selected ? Ui.ACCENT : Ui.MUTED);
            tab.setBackground(selected ? ui.round(Ui.CARD, 10) : null);
        }
    }

    // ---------------------------------------------------------------------------------------------
    // Mods tab
    // ---------------------------------------------------------------------------------------------

    private void buildModsPanel(LinearLayout p) {
        LinearLayout gameCard = ui.card();
        gameCard.addView(ui.text("Game mods folder", 13, Ui.MUTED, false));
        gameFolderText = ui.text("", 14, Ui.TEXT, false);
        gameFolderText.setPadding(0, ui.dp(4), 0, ui.dp(10));
        gameCard.addView(gameFolderText);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(ui.button("Choose folder", false, v -> pickGameFolder()), ui.weighted(0, 4));
        row.addView(ui.button("Sync to game", true, v -> syncToGame()), ui.weighted(4, 0));
        gameCard.addView(row);
        ui.add(p, gameCard, 8);

        ui.add(p, ui.button("Import .geode files", false, v -> pickImport()), 12);
        ui.add(p, ui.text("Your mods", 13, Ui.MUTED, false), 18);

        modsList = new LinearLayout(this);
        modsList.setOrientation(LinearLayout.VERTICAL);
        ui.add(p, modsList, 4);
    }

    private void refreshGameFolder() {
        String saved = prefs.getString(KEY_TREE, null);
        if (saved == null) {
            gameFolderText.setText("Not set yet. Tap Choose folder and pick Geode's mods folder.");
            return;
        }
        try {
            gameFolderText.setText(DocumentsContract.getTreeDocumentId(Uri.parse(saved)));
        } catch (RuntimeException e) {
            gameFolderText.setText(saved);
        }
    }

    private void refreshMods() {
        modsList.removeAllViews();
        List<ModLibrary.Entry> entries = library.list();
        if (entries.isEmpty()) {
            TextView empty = ui.text("No mods yet. Tap Import and pick one or more .geode files.", 14, Ui.MUTED, false);
            empty.setPadding(0, ui.dp(8), 0, 0);
            modsList.addView(empty);
            return;
        }
        for (ModLibrary.Entry e : entries) {
            ui.add(modsList, modRow(e), 8);
        }
    }

    private View modRow(final ModLibrary.Entry e) {
        LinearLayout card = ui.card();
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.addView(ui.text(e.displayName(), 16, Ui.TEXT, true));

        StringBuilder sub = new StringBuilder();
        if (e.info != null) {
            if (!e.info.version.isEmpty()) sub.append(e.info.version);
            if (!e.info.developer.isEmpty()) {
                if (sub.length() > 0) sub.append(" · ");
                sub.append("by ").append(e.info.developer);
            }
        } else {
            sub.append("Could not read this file as a Geode mod");
        }
        if (sub.length() > 0) info.addView(ui.text(sub.toString(), 12, Ui.MUTED, false));
        info.addView(ui.text(e.id, 12, Ui.MUTED, false));
        if (e.info != null && !e.info.description.isEmpty()) {
            TextView desc = ui.text(e.info.description, 13, Ui.TEXT, false);
            desc.setMaxLines(2);
            desc.setEllipsize(TextUtils.TruncateAt.END);
            desc.setPadding(0, ui.dp(4), 0, 0);
            info.addView(desc);
        }
        card.addView(info, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Switch toggle = new Switch(this);
        toggle.setChecked(e.enabled);
        toggle.setOnCheckedChangeListener((button, checked) -> setModEnabled(e.id, checked));
        card.addView(toggle, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView remove = ui.text("✕", 18, Ui.DANGER, true);
        remove.setPadding(ui.dp(14), ui.dp(8), ui.dp(4), ui.dp(8));
        remove.setOnClickListener(v -> confirmRemove(e));
        card.addView(remove, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return card;
    }

    private void setModEnabled(String id, boolean enabled) {
        try {
            library.setEnabled(id, enabled);
        } catch (IOException ex) {
            toast("Could not change " + id + ": " + ex.getMessage());
            refreshMods();
        }
    }

    private void confirmRemove(final ModLibrary.Entry e) {
        new AlertDialog.Builder(this)
                .setTitle("Remove " + e.displayName() + "?")
                .setMessage("This deletes it from GDM. A copy already in the game folder stays there. "
                        + "To take it out of the game too, disable it and sync first.")
                .setPositiveButton("Remove", (dialog, which) -> {
                    try {
                        library.remove(e.id);
                    } catch (IOException ex) {
                        toast("Could not remove " + e.id + ": " + ex.getMessage());
                    }
                    refreshMods();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void pickImport() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(intent, REQ_IMPORT);
    }

    private void pickGameFolder() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.putExtra(DocumentsContract.EXTRA_INITIAL_URI,
                DocumentsContract.buildDocumentUri("com.android.externalstorage.documents", GEODE_MODS_DOC_ID));
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        startActivityForResult(intent, REQ_TREE);
    }

    private void importUris(final List<Uri> uris) {
        toast("Importing…");
        runInBackground(() -> {
            int imported = 0;
            List<String> problems = new ArrayList<>();
            for (Uri uri : uris) {
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    if (in == null) throw new IOException("could not open the file");
                    library.importMod(in);
                    imported++;
                } catch (Exception ex) {
                    String name = uri.getLastPathSegment();
                    problems.add((name == null ? "file" : name) + ": " + ex.getMessage());
                }
            }
            StringBuilder msg = new StringBuilder("Imported " + imported + (imported == 1 ? " mod" : " mods"));
            if (!problems.isEmpty()) msg.append("\nSkipped:\n").append(String.join("\n", problems));
            final String text = msg.toString();
            runOnUiThread(() -> {
                refreshMods();
                toast(text);
            });
        });
    }

    private void syncToGame() {
        String saved = prefs.getString(KEY_TREE, null);
        if (saved == null) {
            toast("Choose the game's mods folder first.");
            pickGameFolder();
            return;
        }
        final Uri tree = Uri.parse(saved);
        final List<ModLibrary.Entry> mods = library.list();
        if (mods.isEmpty()) {
            toast("Import some mods first.");
            return;
        }
        toast("Syncing…");
        runInBackground(() -> {
            GameSync.Result r = GameSync.sync(getContentResolver(), tree, mods);
            StringBuilder msg = new StringBuilder("Synced: " + r.copied + " copied, " + r.removed + " removed.");
            if (!r.problems.isEmpty()) msg.append("\nProblems:\n").append(String.join("\n", r.problems));
            toast(msg.toString());
        });
    }

    // ---------------------------------------------------------------------------------------------
    // Maker tab
    // ---------------------------------------------------------------------------------------------

    private void buildMakerPanel(LinearLayout p) {
        p.addView(ui.text("Create a Geode mod project", 18, Ui.TEXT, true));
        ui.add(p, ui.text("Fill this in and GDM saves a ready-to-build project as a .zip file.", 13, Ui.MUTED, false), 4);

        nameField = labeledField(p, "Mod name", "Cool Mod", null);
        devField = labeledField(p, "Developer", "Your name", null);
        idField = labeledField(p, "Mod ID (lowercase, like yourname.cool-mod)", "yourname.cool-mod", null);
        descField = labeledField(p, "Short description", "One sentence about your mod", null);
        versionField = labeledField(p, "Mod version", "v1.0.0", "v1.0.0");
        geodeField = labeledField(p, "Geode version (match the SDK you build with)", "v5.0.0", ModSpec.DEFAULT_GEODE);
        gdField = labeledField(p, "Geometry Dash version", "2.2081", ModSpec.DEFAULT_GD);

        ModSpec.Template[] templates = ModSpec.Template.values();
        String[] labels = new String[templates.length];
        for (int i = 0; i < templates.length; i++) labels[i] = templates[i].label;
        templateSpinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, labels);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        templateSpinner.setAdapter(adapter);
        ui.add(p, ui.text("Starter code", 13, Ui.MUTED, false), 14);
        ui.add(p, templateSpinner, 4);

        // The mod ID follows "developer.mod-name" until the user types their own.
        TextWatcher autoId = new SimpleWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                if (idEdited) return;
                autoFilling = true;
                idField.setText(ModSpec.suggestId(devField.getText().toString(), nameField.getText().toString()));
                autoFilling = false;
            }
        };
        nameField.addTextChangedListener(autoId);
        devField.addTextChangedListener(autoId);
        idField.addTextChangedListener(new SimpleWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                if (!autoFilling) idEdited = s.length() > 0;
            }
        });

        makerError = ui.text("", 13, Ui.DANGER, false);
        makerError.setVisibility(View.GONE);
        ui.add(p, makerError, 12);
        ui.add(p, ui.button("Generate & save project (.zip)", true, v -> generateProject()), 12);

        makerPreview = ui.text("", 12, Ui.MUTED, false);
        makerPreview.setTypeface(Typeface.MONOSPACE);
        makerPreview.setTextIsSelectable(true);
        ui.add(p, makerPreview, 16);
    }

    private EditText labeledField(LinearLayout p, String label, String hint, String initial) {
        ui.add(p, ui.text(label, 13, Ui.MUTED, false), 14);
        EditText field = ui.field(hint, initial);
        ui.add(p, field, 4);
        return field;
    }

    private ModSpec readSpec() {
        ModSpec s = new ModSpec();
        s.name = nameField.getText().toString();
        s.developer = devField.getText().toString();
        s.id = idField.getText().toString();
        s.description = descField.getText().toString();
        s.version = versionField.getText().toString();
        s.geodeVersion = geodeField.getText().toString();
        s.gdVersion = gdField.getText().toString();
        int position = templateSpinner.getSelectedItemPosition();
        ModSpec.Template[] templates = ModSpec.Template.values();
        s.template = templates[position >= 0 && position < templates.length ? position : 0];
        return s;
    }

    private void generateProject() {
        ModSpec spec = readSpec();
        spec.normalize();
        List<String> errors = spec.validate();
        if (!errors.isEmpty()) {
            makerError.setText(String.join("\n", errors));
            makerError.setVisibility(View.VISIBLE);
            return;
        }
        makerError.setVisibility(View.GONE);

        Map<String, String> files = ProjectGenerator.generate(spec);
        StringBuilder preview = new StringBuilder("Project files:\n");
        for (String path : files.keySet()) {
            preview.append("  ").append(spec.fileBase()).append('/').append(path).append('\n');
        }
        preview.append("\nmod.json\n").append(files.get("mod.json"));
        makerPreview.setText(preview.toString());

        pendingSpec = spec;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/zip");
        intent.putExtra(Intent.EXTRA_TITLE, spec.fileBase() + "-geode-project.zip");
        startActivityForResult(intent, REQ_SAVE_ZIP);
    }

    private void saveProjectZip(final Uri uri) {
        final ModSpec spec = pendingSpec;
        if (spec == null) {
            toast("Press Generate again.");
            return;
        }
        runInBackground(() -> {
            try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
                if (out == null) throw new IOException("could not open the file for writing");
                Map<String, String> files = ProjectGenerator.generate(spec);
                ProjectGenerator.writeZip(files, out, spec.fileBase());
                toast("Saved " + files.size() + " files. Unzip it and follow the README inside.");
            } catch (Exception ex) {
                toast("Could not save the project: " + ex.getMessage());
            }
        });
    }

    // ---------------------------------------------------------------------------------------------
    // Setup tab
    // ---------------------------------------------------------------------------------------------

    private void buildSetupPanel(LinearLayout p) {
        section(p, "What GDM is",
                "GDM keeps your Geometry Dash mods in one place, lets you switch them on or off, and copies the "
                        + "enabled ones into Geode's mods folder. It also has a mod maker that generates a Geode mod project for you.\n\n"
                        + "GDM does not inject code into the game by itself. Mods are loaded by Geode, so you still need "
                        + "Geode's Android launcher installed (docs.geode-sdk.org).");
        section(p, "Install mods",
                "1. Install Geode's Android launcher and start the game once so its folders exist.\n"
                        + "2. Mods tab > Choose folder, and pick the game's mods folder. Geode's docs put it at "
                        + "Android/media/com.geode.launcher/game/geode/mods (the picker starts there when it can).\n"
                        + "3. Import .geode files, switch mods on or off, then tap Sync to game. Disabled mods are removed "
                        + "from the game folder on sync. Files GDM doesn't know about are never touched.");
        section(p, "Make a mod",
                "1. Maker tab: fill in the form and tap Generate. Save the .zip.\n"
                        + "2. Unzip it, upload the files to a new GitHub repository, and run the Build mod workflow in the Actions tab.\n"
                        + "3. Download the build output, import the .geode file here, and sync.\n\n"
                        + "Your mod's code lives in src/main.cpp (C++). The project's README.md repeats these steps.");
        section(p, "Heads up",
                "Geode and Geometry Dash update often. If a build or a mod is rejected over versions, check the Geode and "
                        + "Geometry Dash version fields; the maker's defaults are only suggestions. Only install mods you trust.");
    }

    private void section(LinearLayout p, String title, String body) {
        LinearLayout card = ui.card();
        card.addView(ui.text(title, 16, Ui.ACCENT, true));
        TextView text = ui.text(body, 14, Ui.TEXT, false);
        text.setLineSpacing(0f, 1.15f);
        text.setPadding(0, ui.dp(6), 0, 0);
        card.addView(text);
        ui.add(p, card, 12);
    }

    // ---------------------------------------------------------------------------------------------
    // Results and helpers
    // ---------------------------------------------------------------------------------------------

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;

        if (requestCode == REQ_IMPORT) {
            List<Uri> uris = new ArrayList<>();
            ClipData clip = data.getClipData();
            if (clip != null) {
                for (int i = 0; i < clip.getItemCount(); i++) uris.add(clip.getItemAt(i).getUri());
            } else if (data.getData() != null) {
                uris.add(data.getData());
            }
            if (!uris.isEmpty()) importUris(uris);
        } else if (requestCode == REQ_TREE) {
            Uri uri = data.getData();
            if (uri == null) return;
            try {
                getContentResolver().takePersistableUriPermission(uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            } catch (SecurityException ex) {
                toast("Android did not allow access to that folder. Try choosing it again.");
                return;
            }
            prefs.edit().putString(KEY_TREE, uri.toString()).apply();
            refreshGameFolder();
            String docId = DocumentsContract.getTreeDocumentId(uri);
            if (!docId.endsWith("/mods")) {
                toast("Heads up: this folder isn't named \"mods\". Mods will be copied into it anyway.");
            }
        } else if (requestCode == REQ_SAVE_ZIP) {
            Uri uri = data.getData();
            if (uri != null) saveProjectZip(uri);
        }
    }

    private void runInBackground(Runnable work) {
        new Thread(work, "gdm-worker").start();
    }

    private void toast(final String message) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show());
    }

    /** TextWatcher where only afterTextChanged needs writing. */
    private abstract static class SimpleWatcher implements TextWatcher {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }
    }
}
