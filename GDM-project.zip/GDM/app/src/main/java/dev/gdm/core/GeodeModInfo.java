package dev.gdm.core;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;

/** Metadata read from the mod.json inside a .geode file (a .geode file is a zip archive). */
public final class GeodeModInfo {
    public final String id;
    public final String name;
    public final String version;
    public final String developer;
    public final String description;

    private GeodeModInfo(String id, String name, String version, String developer, String description) {
        this.id = id;
        this.name = name;
        this.version = version;
        this.developer = developer;
        this.description = description;
    }

    /** Reads mod.json from a .geode (zip) file. Throws IOException with a readable message when it is not a mod. */
    public static GeodeModInfo read(File file) throws IOException {
        try (ZipFile zip = new ZipFile(file)) {
            ZipEntry entry = zip.getEntry("mod.json");
            if (entry == null) throw new IOException("Not a Geode mod: there is no mod.json inside");
            String text = readAll(zip.getInputStream(entry));
            Object parsed;
            try {
                parsed = MiniJson.parse(text);
            } catch (IllegalArgumentException ex) {
                throw new IOException("mod.json is not valid JSON (" + ex.getMessage() + ")");
            }
            if (!(parsed instanceof Map)) throw new IOException("mod.json must be a JSON object");
            Map<?, ?> m = (Map<?, ?>) parsed;

            String id = str(m, "id");
            if (id.isEmpty()) throw new IOException("mod.json has no \"id\"");
            String name = str(m, "name");
            String developer = str(m, "developer");
            if (developer.isEmpty()) {
                Object devs = m.get("developers");
                if (devs instanceof List && !((List<?>) devs).isEmpty()) {
                    Object first = ((List<?>) devs).get(0);
                    if (first instanceof String) developer = (String) first;
                }
            }
            return new GeodeModInfo(id, name.isEmpty() ? id : name, str(m, "version"), developer, str(m, "description"));
        } catch (ZipException ex) {
            throw new IOException("That file is not a valid .geode (zip) archive");
        }
    }

    private static String str(Map<?, ?> m, String key) {
        Object v = m.get(key);
        return v instanceof String ? ((String) v).trim() : "";
    }

    private static String readAll(InputStream in) throws IOException {
        try (InputStream is = in) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = is.read(buf)) > 0) out.write(buf, 0, n);
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        }
    }
}
