package dev.gdm.core;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Generates the files of a Geode mod project (mod.json, CMake, C++ starter, GitHub build workflow).
 * The layout follows the standard Geode mod template; if Geode changes its template,
 * `geode new` on a computer always produces the up-to-date one.
 */
public final class ProjectGenerator {
    private ProjectGenerator() {
    }

    /** Returns relative path -> file content, in a stable order. Throws IllegalArgumentException if the spec is invalid. */
    public static LinkedHashMap<String, String> generate(ModSpec input) {
        ModSpec s = input.copy();
        s.normalize();
        List<String> errors = s.validate();
        if (!errors.isEmpty()) throw new IllegalArgumentException(String.join("\n", errors));

        LinkedHashMap<String, String> files = new LinkedHashMap<>();
        files.put("mod.json", modJson(s));
        files.put("CMakeLists.txt", cmake(s));
        files.put("src/main.cpp", mainCpp(s));
        files.put("about.md", aboutMd(s));
        files.put("changelog.md", changelogMd(s));
        files.put("README.md", readmeMd(s));
        files.put(".gitignore", GITIGNORE);
        files.put(".github/workflows/build.yml", WORKFLOW);
        return files;
    }

    /** Writes the files as a zip with everything inside one top-level folder. Does not close the stream. */
    public static void writeZip(Map<String, String> files, OutputStream out, String rootFolder) throws IOException {
        ZipOutputStream zip = new ZipOutputStream(out, StandardCharsets.UTF_8);
        for (Map.Entry<String, String> e : files.entrySet()) {
            zip.putNextEntry(new ZipEntry(rootFolder + "/" + e.getKey()));
            zip.write(e.getValue().getBytes(StandardCharsets.UTF_8));
            zip.closeEntry();
        }
        zip.finish();
        zip.flush();
    }

    // ---- file builders -------------------------------------------------------------------------

    private static String modJson(ModSpec s) {
        String description = s.description.isEmpty() ? "A Geode mod made with GDM." : s.description;
        StringBuilder b = new StringBuilder();
        b.append("{\n");
        b.append("    \"geode\": ").append(q(s.geodeVersion)).append(",\n");
        b.append("    \"gd\": {\n");
        b.append("        \"android\": ").append(q(s.gdVersion)).append("\n");
        b.append("    },\n");
        b.append("    \"id\": ").append(q(s.id)).append(",\n");
        b.append("    \"name\": ").append(q(s.name)).append(",\n");
        b.append("    \"version\": ").append(q(s.version)).append(",\n");
        b.append("    \"developer\": ").append(q(s.developer)).append(",\n");
        b.append("    \"description\": ").append(q(description)).append("\n");
        b.append("}\n");
        return b.toString();
    }

    private static String cmake(ModSpec s) {
        return CMAKE
                .replace("@@PROJECT@@", s.cmakeName())
                .replace("@@VERSION@@", s.versionNumbers());
    }

    private static String mainCpp(ModSpec s) {
        if (s.template == ModSpec.Template.EMPTY) return MAIN_EMPTY;
        return MAIN_HELLO.replace("@@NAME@@", cpp(s.name));
    }

    private static String aboutMd(ModSpec s) {
        String description = s.description.isEmpty() ? "A Geode mod made with GDM." : s.description;
        return "# " + s.name + "\n\n" + description + "\n\nMade by " + s.developer + ".\n";
    }

    private static String changelogMd(ModSpec s) {
        return "## " + s.version + "\n\n- Initial release\n";
    }

    private static String readmeMd(ModSpec s) {
        return README
                .replace("@@NAME@@", s.name)
                .replace("@@ID@@", s.id);
    }

    // ---- escaping ------------------------------------------------------------------------------

    /** JSON string literal with quotes. */
    static String q(String v) {
        StringBuilder b = new StringBuilder("\"");
        for (int i = 0; i < v.length(); i++) {
            char c = v.charAt(i);
            switch (c) {
                case '"':
                    b.append("\\\"");
                    break;
                case '\\':
                    b.append("\\\\");
                    break;
                case '\n':
                    b.append("\\n");
                    break;
                case '\r':
                    b.append("\\r");
                    break;
                case '\t':
                    b.append("\\t");
                    break;
                default:
                    if (c < 0x20) b.append(String.format("\\u%04x", (int) c));
                    else b.append(c);
            }
        }
        return b.append('"').toString();
    }

    /** Escapes text so it can sit inside a C++ "string literal". */
    static String cpp(String v) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < v.length(); i++) {
            char c = v.charAt(i);
            switch (c) {
                case '"':
                    b.append("\\\"");
                    break;
                case '\\':
                    b.append("\\\\");
                    break;
                case '\n':
                case '\r':
                    b.append(' ');
                    break;
                case '?':
                    b.append("\\?"); // avoids trigraph surprises
                    break;
                default:
                    if (c < 0x20) b.append(' ');
                    else b.append(c);
            }
        }
        return b.toString();
    }

    // ---- templates -----------------------------------------------------------------------------

    private static final String CMAKE = """
            cmake_minimum_required(VERSION 3.25)
            set(CMAKE_CXX_STANDARD 23)
            set(CMAKE_CXX_STANDARD_REQUIRED ON)
            set(CMAKE_CXX_VISIBILITY_PRESET hidden)

            project(@@PROJECT@@ VERSION @@VERSION@@)

            file(GLOB SOURCES
                src/*.cpp
            )

            add_library(${PROJECT_NAME} SHARED ${SOURCES})

            if (NOT DEFINED ENV{GEODE_SDK})
                message(FATAL_ERROR "Unable to find Geode SDK! Please define GEODE_SDK environment variable to point to Geode")
            else()
                message(STATUS "Found Geode: $ENV{GEODE_SDK}")
            endif()

            add_subdirectory($ENV{GEODE_SDK} ${CMAKE_CURRENT_BINARY_DIR}/geode)

            setup_geode_mod(${PROJECT_NAME})
            """;

    private static final String MAIN_HELLO = """
            #include <Geode/Geode.hpp>

            using namespace geode::prelude;

            #include <Geode/modify/MenuLayer.hpp>
            class $modify(MyMenuLayer, MenuLayer) {
                bool init() {
                    if (!MenuLayer::init()) {
                        return false;
                    }

                    log::debug("Hello from my MenuLayer::init hook! This layer has {} children.", this->getChildrenCount());

                    auto myButton = CCMenuItemSpriteExtra::create(
                        CCSprite::createWithSpriteFrameName("GJ_likeBtn_001.png"),
                        this,
                        menu_selector(MyMenuLayer::onMyButton)
                    );

                    auto menu = this->getChildByID("bottom-menu");
                    menu->addChild(myButton);

                    myButton->setID("my-button"_spr);

                    menu->updateLayout();

                    return true;
                }

                void onMyButton(CCObject*) {
                    FLAlertLayer::create("Geode", "Hello from @@NAME@@!", "OK")->show();
                }
            };
            """;

    private static final String MAIN_EMPTY = """
            #include <Geode/Geode.hpp>

            using namespace geode::prelude;

            $on_mod(Loaded) {
                log::info("{} loaded!", Mod::get()->getName());
            }
            """;

    private static final String GITIGNORE = """
            build/
            build-*/
            .cache/
            .idea/
            .vscode/
            CMakeUserPresets.json
            """;

    private static final String WORKFLOW = """
            name: Build mod

            on:
              workflow_dispatch:
              push:
                branches:
                  - "**"

            jobs:
              build:
                strategy:
                  fail-fast: false
                  matrix:
                    config:
                      - name: Android 32-bit
                        os: ubuntu-latest
                        target: Android32
                      - name: Android 64-bit
                        os: ubuntu-latest
                        target: Android64

                name: ${{ matrix.config.name }}
                runs-on: ${{ matrix.config.os }}

                steps:
                  - uses: actions/checkout@v4

                  - name: Build the mod
                    uses: geode-sdk/build-geode-mod@main
                    with:
                      combine: true
                      target: ${{ matrix.config.target }}

              package:
                name: Package builds
                runs-on: ubuntu-latest
                needs: ['build']

                steps:
                  - uses: geode-sdk/build-geode-mod/combine@main
                    id: build

                  - uses: actions/upload-artifact@v4
                    with:
                      name: Build Output
                      path: ${{ steps.build.outputs.build-output }}
            """;

    private static final String README = """
            # @@NAME@@

            A Geode mod (`@@ID@@`) made with GDM.

            ## Build it on your phone (no computer needed)

            1. Create a free GitHub account and a new repository.
            2. Upload every file of this project. Keep the folders, especially `.github/workflows/build.yml`.
            3. Open the repository's **Actions** tab, choose **Build mod** and run it (pushing a commit also starts it).
            4. When the run turns green, open it and download **Build Output**. Unzip it: the `.geode` file inside is your mod.
            5. In GDM, open the Mods tab, import that `.geode` file, then sync it to the game.

            ## Build it on a computer

            Install the Geode CLI and run `geode build` in this folder. Setup guide: https://docs.geode-sdk.org/

            ## Good to know

            - This project targets Android only (see `gd` in `mod.json`). To support more platforms, add them to `gd` and to the workflow.
            - `geode` in `mod.json` must match the Geode version you build against. If the build complains about a version mismatch, change it.
            - Add a `logo.png` next to `mod.json` if you want a custom icon in Geode's mod list.
            """;
}
