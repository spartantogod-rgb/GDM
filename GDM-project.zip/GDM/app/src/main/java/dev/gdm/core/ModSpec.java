package dev.gdm.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/** Everything the mod maker needs to know to generate a Geode mod project. */
public final class ModSpec {

    public enum Template {
        HELLO_BUTTON("Hello button (hooks the main menu)"),
        EMPTY("Empty mod (just logs when loaded)");

        public final String label;

        Template(String label) {
            this.label = label;
        }
    }

    /** Defaults are only suggestions. The Geode version must match the SDK you build against. */
    public static final String DEFAULT_GEODE = "v5.11.2";
    public static final String DEFAULT_GD = "2.2081";

    private static final Pattern ID = Pattern.compile("^[a-z0-9_.-]+$");
    private static final Pattern VERSION = Pattern.compile("^v\\d+\\.\\d+\\.\\d+(-[0-9A-Za-z.-]+)?$");
    private static final Pattern GD = Pattern.compile("^(\\*|\\d+\\.\\d+)$");

    public String name = "";
    public String developer = "";
    public String id = "";
    public String description = "";
    public String version = "v1.0.0";
    public String geodeVersion = DEFAULT_GEODE;
    public String gdVersion = DEFAULT_GD;
    public Template template = Template.HELLO_BUTTON;

    public ModSpec copy() {
        ModSpec c = new ModSpec();
        c.name = name;
        c.developer = developer;
        c.id = id;
        c.description = description;
        c.version = version;
        c.geodeVersion = geodeVersion;
        c.gdVersion = gdVersion;
        c.template = template;
        return c;
    }

    /** Trims fields, lower-cases the id, puts a leading "v" on versions and flattens the description to one line. */
    public void normalize() {
        name = nz(name).trim();
        developer = nz(developer).trim();
        id = nz(id).trim().toLowerCase(Locale.ROOT);
        description = nz(description).replaceAll("\\s+", " ").trim();
        version = withV(nz(version).trim());
        geodeVersion = withV(nz(geodeVersion).trim());
        gdVersion = nz(gdVersion).trim();
        if (template == null) template = Template.HELLO_BUTTON;
    }

    /** Call normalize() first. Returns human-readable problems; empty means the spec is fine. */
    public List<String> validate() {
        List<String> errors = new ArrayList<>();
        if (name.isEmpty()) errors.add("Give your mod a name.");
        else if (name.length() > 64) errors.add("The mod name is too long (64 characters max).");
        if (developer.isEmpty()) errors.add("Enter a developer name.");
        if (id.isEmpty()) {
            errors.add("Enter a mod ID, like yourname.cool-mod.");
        } else if (id.length() < 3 || !ID.matcher(id).matches()) {
            errors.add("The mod ID can only use lowercase letters, numbers, '.', '_' and '-' (at least 3 characters).");
        }
        if (!VERSION.matcher(version).matches()) errors.add("The mod version must look like v1.0.0.");
        if (!VERSION.matcher(geodeVersion).matches()) errors.add("The Geode version must look like v5.0.0.");
        if (!GD.matcher(gdVersion).matches()) errors.add("The Geometry Dash version must look like 2.2081 (or * for any).");
        return errors;
    }

    /** "v1.2.3-beta" becomes "1.2.3" (CMake wants plain numbers). */
    public String versionNumbers() {
        String v = version.startsWith("v") ? version.substring(1) : version;
        int dash = v.indexOf('-');
        return dash >= 0 ? v.substring(0, dash) : v;
    }

    /** A C++/CMake-safe project name, e.g. "Cool Mod" becomes "CoolMod". */
    public String cmakeName() {
        String s = name.replaceAll("[^A-Za-z0-9_]+", "");
        if (s.isEmpty()) return "MyMod";
        if (Character.isDigit(s.charAt(0))) return "Mod" + s;
        return s;
    }

    /** Folder / file name base like "cool-mod". */
    public String fileBase() {
        String s = slug(name);
        return s.isEmpty() ? "my-mod" : s;
    }

    public static String slug(String s) {
        String t = s == null ? "" : s.toLowerCase(Locale.ROOT);
        t = t.replaceAll("[^a-z0-9]+", "-");
        t = t.replaceAll("^-+|-+$", "");
        return t;
    }

    /** Suggests "developer.mod-name" for the mod ID. */
    public static String suggestId(String developer, String name) {
        String d = slug(developer);
        String n = slug(name);
        if (d.isEmpty()) return n;
        if (n.isEmpty()) return d;
        return d + "." + n;
    }

    private static String withV(String v) {
        if (v.isEmpty() || v.startsWith("v")) return v;
        return "v" + v;
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }
}
