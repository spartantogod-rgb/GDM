package dev.gdm.core;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * GDM's own folder of mods. An enabled mod is "<id>.geode", a disabled one is "<id>.geode.disabled".
 * Nothing here touches the game; GameSync copies enabled mods into the game's mods folder.
 */
public final class ModLibrary {
    private static final String ON = ".geode";
    private static final String OFF = ".geode.disabled";
    private static final Pattern SAFE_ID = Pattern.compile("^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$");

    /** A snapshot of one mod in the library. */
    public static final class Entry {
        public final String id;
        public final boolean enabled;
        public final File file;
        /** null when the file could not be read as a Geode mod. */
        public final GeodeModInfo info;

        Entry(String id, boolean enabled, File file, GeodeModInfo info) {
            this.id = id;
            this.enabled = enabled;
            this.file = file;
            this.info = info;
        }

        public String displayName() {
            return info != null ? info.name : id;
        }
    }

    private final File dir;

    public ModLibrary(File dir) {
        this.dir = dir;
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
    }

    public List<Entry> list() {
        List<Entry> out = new ArrayList<>();
        File[] files = dir.listFiles();
        if (files == null) return out;
        for (File f : files) {
            String n = f.getName();
            boolean disabled = n.endsWith(OFF);
            boolean enabled = !disabled && n.endsWith(ON);
            if (!disabled && !enabled) continue;
            String id = n.substring(0, n.length() - (disabled ? OFF.length() : ON.length()));
            GeodeModInfo info = null;
            try {
                info = GeodeModInfo.read(f);
            } catch (IOException ignored) {
                // shown with its file name only
            }
            out.add(new Entry(id, enabled, f, info));
        }
        Collections.sort(out, new Comparator<Entry>() {
            @Override
            public int compare(Entry a, Entry b) {
                return a.displayName().toLowerCase(Locale.ROOT).compareTo(b.displayName().toLowerCase(Locale.ROOT));
            }
        });
        return out;
    }

    /**
     * Copies a .geode file from the stream into the library after checking it really is a Geode mod.
     * Importing a mod that already exists replaces it and keeps its enabled/disabled state.
     */
    public Entry importMod(InputStream in) throws IOException {
        File tmp = File.createTempFile("import-", ".tmp", dir);
        try {
            try (OutputStream out = new FileOutputStream(tmp)) {
                copy(in, out);
            }
            GeodeModInfo info = GeodeModInfo.read(tmp);
            if (!SAFE_ID.matcher(info.id).matches()) {
                throw new IOException("The mod id \"" + info.id + "\" has characters GDM can't store safely");
            }
            File on = new File(dir, info.id + ON);
            File off = new File(dir, info.id + OFF);
            boolean keepDisabled = off.exists();
            Files.deleteIfExists(on.toPath());
            Files.deleteIfExists(off.toPath());
            File target = keepDisabled ? off : on;
            Files.move(tmp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING);
            return new Entry(info.id, !keepDisabled, target, info);
        } finally {
            //noinspection ResultOfMethodCallIgnored
            tmp.delete();
        }
    }

    public void setEnabled(String id, boolean enabled) throws IOException {
        if (!SAFE_ID.matcher(id).matches()) throw new IOException("Bad mod id");
        File on = new File(dir, id + ON);
        File off = new File(dir, id + OFF);
        File from = enabled ? off : on;
        File to = enabled ? on : off;
        if (!from.exists()) return; // already in the requested state (or gone)
        Files.move(from.toPath(), to.toPath(), StandardCopyOption.REPLACE_EXISTING);
    }

    public void remove(String id) throws IOException {
        if (!SAFE_ID.matcher(id).matches()) throw new IOException("Bad mod id");
        Files.deleteIfExists(new File(dir, id + ON).toPath());
        Files.deleteIfExists(new File(dir, id + OFF).toPath());
    }

    public static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[64 * 1024];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
    }
}
